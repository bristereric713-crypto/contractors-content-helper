import express from "express";
import fetch from "node-fetch";

const app = express();

// Serve your frontend files
app.use(express.static("public"));
app.use(express.json());

// Securely return your API key from Replit Secrets
app.get("/key", (req, res) => {
  res.json({ key: process.env.OPENAI_API_KEY });
});

// Secure API proxy
app.post("/gpt", async (req, res) => {
  const { prompt } = req.body;
  const key = process.env.OPENAI_API_KEY;

  try {
    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${key}`
      },
      body: JSON.stringify({
        model: "gpt-4o",
        messages: [{ role: "user", content: prompt }]
      })
    });

    const data = await response.json();
    res.json({ reply: data.choices[0].message.content });

  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "API error" });
  }
});

app.listen(5000, () => console.log("Server running on port 5000"));
